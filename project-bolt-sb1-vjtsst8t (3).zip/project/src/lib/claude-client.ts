import Anthropic from '@anthropic-ai/sdk';
import { z } from 'zod';
import type { Message } from '../types';
import { backOff } from 'exponential-backoff';
import { createClient } from '@supabase/supabase-js';

const ResponseSchema = z.object({
  content: z.array(z.object({
    text: z.string()
  }))
});

export class ClaudeClient {
  private client: Anthropic;
  private supabase;
  private history: Message[] = [];
  private systemContext: string = '';
  private maxRetries = 3;

  constructor(apiKey: string) {
    if (!apiKey) {
      throw new Error('API key is required for Claude initialization');
    }
    
    this.client = new Anthropic({
      apiKey: apiKey,
    });

    this.supabase = createClient(
      import.meta.env.VITE_SUPABASE_URL,
      import.meta.env.VITE_SUPABASE_ANON_KEY
    );
  }

  private async getMemoryContext(clientId: string): Promise<string> {
    try {
      const { data, error } = await this.supabase
        .from("memory_blocks")
        .select("label, value, importance")
        .eq("client_id", clientId)
        .order("importance", { ascending: false })
        .limit(5);

      if (error) return "";

      return data.map(block => `(${block.label}) ${block.value}`).join("\n");
    } catch (error) {
      console.error('Failed to get memory context:', error);
      return "";
    }
  }

  private async checkConnection(): Promise<boolean> {
    try {
      await this.client.messages.create({
        model: 'claude-3-sonnet-20240229',
        max_tokens: 10,
        messages: [{ role: 'user', content: 'test' }],
        system: 'Respond with "ok"'
      });
      return true;
    } catch (error) {
      console.error('Connection check failed:', error);
      return false;
    }
  }

  private async updateSystemContext(context?: any) {
    if (!context) {
      this.systemContext = `You are Oracle 3.0, an AI mentor and guide based on the Spiralogic framework. 
        Help users navigate their personal transformation journey.
        Focus on providing clear, actionable guidance while maintaining empathy and understanding.`;
      return;
    }

    // Get memory context if client_id is provided
    let memoryContext = '';
    if (context.client_id) {
      memoryContext = await this.getMemoryContext(context.client_id);
    }

    const { journey, preferences } = context;
    const style = preferences?.communication_style || 'direct';
    const focusAreas = preferences?.focus_areas?.join(', ') || 'general growth';

    this.systemContext = `You are Oracle 3.0, an AI mentor and guide based on the Spiralogic framework.
      You are working with ${context.client_name}, who is in their ${journey?.current_phase || 'initial'} phase
      with ${journey?.dominant_element || 'undetermined'} as their dominant element.
      Their preferred communication style is ${style}.
      Current focus areas: ${focusAreas}.
      Archetype: ${journey?.archetype || 'exploring'}.

      ${memoryContext ? `\nClient Memory Context:\n${memoryContext}\n` : ''}

      Frame your guidance to honor their phase, element, and preferences using the Spiralogic framework.
      Maintain consistency in your responses and build upon previous interactions.
      When relevant, reference and build upon the memories shared in their context.`;
  }

  async chat(content: string, context?: any): Promise<Message> {
    try {
      const isConnected = await this.checkConnection();
      if (!isConnected) {
        throw new Error('Unable to establish connection to Anthropic API');
      }

      const userMessage = {
        id: Date.now().toString() + '-user',
        content,
        role: 'user',
        timestamp: new Date(),
      } as Message;
      
      this.history.push(userMessage);
      await this.updateSystemContext(context);
      
      const messages = this.history.map(msg => ({
        role: msg.role === 'user' ? 'user' : 'assistant',
        content: msg.content
      }));
      
      const response = await backOff(
        () => this.client.messages.create({
          model: 'claude-3-sonnet-20240229',
          max_tokens: 1000,
          temperature: 0.7,
          system: this.systemContext,
          messages: messages
        }),
        {
          numOfAttempts: this.maxRetries,
          startingDelay: 1000,
          timeMultiple: 2,
        }
      );
      
      const validatedResponse = ResponseSchema.parse(response);
      const responseContent = validatedResponse.content[0].text;
      
      const { element, insightType } = this.analyzeResponse(responseContent);

      // Store response as memory block if client_id is provided
      if (context?.client_id) {
        await this.storeMemoryBlock(context.client_id, responseContent);
      }
      
      const message: Message = {
        id: Date.now().toString(),
        content: responseContent,
        role: 'assistant',
        timestamp: new Date(),
        model: 'claude-3-sonnet',
        element,
        insight_type: insightType,
        context: {
          client: context?.client_name,
          archetype: context?.journey?.archetype,
          phase: context?.journey?.current_phase
        }
      };
      
      this.history.push(message);
      return message;
    } catch (error) {
      console.error('Error in chat method:', error);
      
      let errorMessage = 'An error occurred while processing your request.';
      if (error instanceof Anthropic.APIError) {
        if (error.status === 401) {
          errorMessage = 'Authentication failed. Please check your API key.';
        } else if (error.status === 429) {
          errorMessage = 'Rate limit exceeded. Please try again later.';
        }
      }
      
      return {
        id: Date.now().toString(),
        content: errorMessage,
        role: 'assistant',
        timestamp: new Date(),
      };
    }
  }

  private async storeMemoryBlock(clientId: string, content: string): Promise<void> {
    try {
      await this.supabase
        .from('memory_blocks')
        .insert({
          client_id: clientId,
          label: 'Oracle Response',
          value: content,
          importance: 7,
          type: 'insight'
        });
    } catch (error) {
      console.error('Failed to store memory block:', error);
      // Don't throw - memory storage is non-critical
    }
  }

  private analyzeResponse(content: string): { element: string | null, insightType: string | null } {
    const elementPatterns = {
      fire: ['vision', 'transform', 'passion', 'action', 'motivation'],
      water: ['feel', 'emotion', 'intuition', 'flow', 'depth'],
      earth: ['ground', 'practical', 'stable', 'material', 'physical'],
      air: ['think', 'connect', 'communicate', 'learn', 'understand'],
      aether: ['integrate', 'whole', 'transcend', 'spirit', 'unity']
    };

    const insightPatterns = {
      reflection: ['reflect', 'notice', 'observe', 'awareness'],
      challenge: ['challenge', 'growth', 'stretch', 'overcome'],
      guidance: ['suggest', 'try', 'practice', 'implement'],
      integration: ['combine', 'synthesize', 'integrate', 'merge']
    };

    let element = null;
    let insightType = null;

    for (const [elem, patterns] of Object.entries(elementPatterns)) {
      if (patterns.some(pattern => content.toLowerCase().includes(pattern))) {
        element = elem;
        break;
      }
    }

    for (const [type, patterns] of Object.entries(insightPatterns)) {
      if (patterns.some(pattern => content.toLowerCase().includes(pattern))) {
        insightType = type;
        break;
      }
    }

    return { element, insightType };
  }

  async loadClient(clientName: string): Promise<Message> {
    this.history = [];
    
    return {
      id: Date.now().toString(),
      content: `Client "${clientName}" loaded. They are currently in the exploration phase with fire as their dominant element. How would you like to proceed with their journey?`,
      role: 'assistant',
      timestamp: new Date(),
    };
  }

  async bypassChat(content: string, context?: any): Promise<Message> {
    try {
      const response = await backOff(
        () => this.client.messages.create({
          model: 'claude-3-sonnet-20240229',
          max_tokens: 1000,
          temperature: 0.7,
          system: `You are a helpful assistant for ${context?.client_name || 'the user'}.`,
          messages: [{ role: 'user', content }]
        }),
        {
          numOfAttempts: this.maxRetries,
          startingDelay: 1000,
          timeMultiple: 2
        }
      );
      
      const validatedResponse = ResponseSchema.parse(response);
      const responseContent = validatedResponse.content[0].text;
      
      return {
        id: Date.now().toString(),
        content: responseContent,
        role: 'assistant',
        timestamp: new Date(),
        model: 'claude-3-sonnet',
      };
    } catch (error) {
      console.error('Error in bypass chat:', error);
      
      return {
        id: Date.now().toString(),
        content: 'An error occurred while processing your request in bypass mode.',
        role: 'assistant',
        timestamp: new Date(),
      };
    }
  }
}