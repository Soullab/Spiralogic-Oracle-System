/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        // Element Colors
        fire: '#a94724',
        air: '#cea22c',
        earth: '#6d7934',
        water: '#236586',
        neutral: {
          black: '#000000',
          gray: '#777777',
          brown: '#33251d',
        },
        // UI Colors
        primary: 'hsl(var(--primary))',
        'primary-foreground': 'hsl(var(--primary-foreground))',
        secondary: 'hsl(var(--secondary))',
        'secondary-foreground': 'hsl(var(--secondary-foreground))',
        accent: 'hsl(var(--accent))',
        'accent-foreground': 'hsl(var(--accent-foreground))',
        background: 'hsl(var(--background))',
        foreground: 'hsl(var(--foreground))',
        card: 'hsl(var(--card))',
        'card-foreground': 'hsl(var(--card-foreground))',
        popover: 'hsl(var(--popover))',
        'popover-foreground': 'hsl(var(--popover-foreground))',
        muted: 'hsl(var(--muted))',
        'muted-foreground': 'hsl(var(--muted-foreground))',
        border: 'hsl(var(--border))',
        input: 'hsl(var(--input))',
        ring: 'hsl(var(--ring))',
      },
      fontFamily: {
        sans: ['Lato', 'sans-serif'],
        display: ['Blair ITC', 'sans-serif'],
      },
      container: {
        center: true,
        padding: '2rem',
        screens: {
          '2xl': '1400px',
        },
      },
      backgroundImage: {
        'sacred-geometry': "url('/patterns/sacred-geometry.svg')",
        'circuit-lines': "url('/patterns/circuit-lines.svg')",
        'elemental-flow': "url('/patterns/elemental-flow.svg')",
      },
    },
  },
  plugins: [],
};